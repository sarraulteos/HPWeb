Action()
{

	web_set_sockets_option("SSL_VERSION", "TLS1.2");

	web_url("login", 
		"URL=https://stg.g6row.com/login", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		LAST);

	web_url("Help", 
		"URL=https://stg.g6row.com/login", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("DT=DI0IzwNYA-uQKSrSlmA5sFvWQ; DOMAIN=g6hospitality.oktapreview.com");

	web_add_cookie("proximity_058b2b59c2422d3b8d642cedfd2f86f0=\"EJ25yVKZcXNmbcS6H7NpGuvK8u0etFo11zFGjjZ+1taOXnhCJ2e7ylHv7uBJt89xNXN8RcyUMwEMx2YbUiFNvbq7JkdzHq7xedb44uAhU1yuW6MqJT7+EVAYYsU1uRDzwE/TTZ9oy6/ip7s3VDcWh0IXtqz2Y1VuniW/kurcbVyOODidxeaG7t5y5bB6vFRt\"; DOMAIN=g6hospitality.oktapreview.com");

	web_submit_data("login_2", 
		"Action=https://stg.g6row.com/login", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://stg.g6row.com/login", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=username", "Value=loadrunner-000@g6hospitality.com", ENDITEM, 
		"Name=password", "Value=N1makeIts3W!", ENDITEM, 
		"Name=_csrf", "Value=19f25c8a-f4cf-400c-be80-05660eb52e70", ENDITEM, 
		LAST);

	web_add_cookie("JSESSIONID=F640B843A036E7DDF6EB2D19859CBA16; DOMAIN=g6hospitality.oktapreview.com");

	web_add_cookie("ADRUM_BTa=\"R:27|g:20718ca3-b411-4a75-910b-b6afd8286144\"; DOMAIN=g6hospitality.oktapreview.com");

	web_add_cookie("ADRUM_BT1=\"R:27|i:10346|e:30\"; DOMAIN=g6hospitality.oktapreview.com");

	web_submit_data("login_3", 
		"Action=https://stg.g6row.com/login", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://stg.g6row.com/login", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=username", "Value=loadrunner-000@g6hospitality.com", ENDITEM, 
		"Name=password", "Value=N1makeIts3W!", ENDITEM, 
		"Name=_csrf", "Value=19f25c8a-f4cf-400c-be80-05660eb52e70", ENDITEM, 
		LAST);

	return 0;
}